package com.capgemini.DAO;

import java.util.List;

import com.capgemini.beans.Product;

public interface IProductRepo {

	boolean save(Product product);

	Product findById(String id);

	List<Product> findAll();
	
	Product update(Product product);

	boolean delete(String id);

}