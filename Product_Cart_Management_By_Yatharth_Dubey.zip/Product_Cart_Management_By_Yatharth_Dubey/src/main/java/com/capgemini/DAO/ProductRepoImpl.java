package com.capgemini.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.beans.Product;

@Repository
public class ProductRepoImpl implements IProductRepo {
	
	@PersistenceContext
	EntityManager em;
	
	/* (non-Javadoc)
	 * @see com.capgemini.repo.ProductRepo#save(com.capgemini.beans.Product)
	 */
	@Override
	@Transactional
	public boolean save(Product product){
		
		if(em.find(Product.class, product.getId()) != null) {
			return false;
		}
		em.persist(product);
		return true; //returning true after saving the Product object in database
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.repo.ProductRepo#findById(java.lang.String)
	 */
	@Override
	public Product findById(String id){
		
		Product product = em.find(Product.class, id);
		if(product != null)
			return product; //returning Product object if found
		return null;
		
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.repo.ProductRepo#findAll()
	 */
	@Override
	public List<Product> findAll(){
		
		Query query = em.createQuery("select p from Product p");
		return query.getResultList(); //returning list of all Products
		
	}
	
	/* (non-Javadoc)
	 * @see com.capgemini.repo.ProductRepo#delete(java.lang.String)
	 */
	@Override
	@Transactional
	public boolean delete(String id) {

		Product product = em.find(Product.class, id);
		if(product!=null) {
			em.remove(product);
			return true; //returning true after successful deletion of Product
		}
		return false;
	
		
		
	}

	@Override
	@Transactional
	public Product update(Product product) {
		
		if(em.find(Product.class, product.getId())==null)
			return null;
		Product product1 = em.find(Product.class, product.getId());
		product1.setName(product.getName());
		product1.setModel(product.getModel());
		product1.setPrice(product.getPrice());
		em.merge(product1);
		return product1; //returning updated Product object
	}

}
