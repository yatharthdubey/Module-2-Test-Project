package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.DAO.IProductRepo;
import com.capgemini.beans.Product;
import com.capgemini.exception.IdAlreadyExistsException;
import com.capgemini.exception.IdNotExistsException;

@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductRepo repo; //Creating reference of Repo layer
	
	/* (non-Javadoc)
	 * @see com.capgemini.service.ProductService#createProduct(com.capgemini.beans.Product)
	 */
	@Override
	public Product createProduct(Product product) {
		
		if(!repo.save(product))
			throw new IdAlreadyExistsException("Id Already Exists"); //throwing exception if id already exists in database
		return product; //returning Product object after saving it in database
			
		
	}
	
	
	/* (non-Javadoc)
	 * @see com.capgemini.service.ProductService#updateProduct(com.capgemini.beans.Product)
	 */
	@Override
	public Product updateProduct(Product product) {
		
		if(repo.update(product)==null)
			throw new IdNotExistsException("Id Not Exists"); //throwing exception if id does not exist in database
		return repo.update(product); //returning updated Product object after updating it in database
	}

	
	/* (non-Javadoc)
	 * @see com.capgemini.service.ProductService#deleteProduct(java.lang.String)
	 */
	@Override
	public boolean deleteProduct(String id) {
		
		if(!repo.delete(id))
			throw new IdNotExistsException("Id Not Exists"); //throwing exception if id does not exist in database
		return true; //returning true if deletion is successful
	}
	
	
	/* (non-Javadoc)
	 * @see com.capgemini.service.ProductService#viewProduct(java.lang.String)
	 */
	@Override
	public Product viewProduct(String id) {
		
		Product product = repo.findById(id);
		if(product == null)
			throw new IdNotExistsException("Id Not Exists"); //throwing exception if id does not exist in database
		return product; //returning Product object if found in database
	}
	
	
	/* (non-Javadoc)
	 * @see com.capgemini.service.ProductService#viewAllProducts()
	 */
	@Override
	public List<Product> viewAllProducts() {
		
		return repo.findAll(); //calling findAll() method of repo to retrieve all product details
	}
}
