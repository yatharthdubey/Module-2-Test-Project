package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.Product;

public interface IProductService {

	Product createProduct(Product product);

	Product updateProduct(Product product);

	boolean deleteProduct(String id);

	Product viewProduct(String id);

	List<Product> viewAllProducts();

}