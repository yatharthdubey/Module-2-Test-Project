package com.capgemini.exception;

public class IdNotExistsException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public IdNotExistsException(String message) {
		super(message);
	}

}
