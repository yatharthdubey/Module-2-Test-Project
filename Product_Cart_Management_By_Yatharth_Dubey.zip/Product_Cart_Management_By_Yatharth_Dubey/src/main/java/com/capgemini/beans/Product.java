package com.capgemini.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="product_cart_table")
public class Product {
	
	/*
	 * Attributes of Product class along with Spring MVC Validation 
	 */
	@Id
	@NotNull(message="Id cannot be null")
	@NotEmpty(message="Id cannot be empty")
	private String id;

	@NotNull(message="Name cannot be null")
	@NotEmpty(message="Name cannot be empty")
	private String name;
	
	@NotNull(message="Model cannot be null")
	@NotEmpty(message="Model cannot be empty")
	private String model;
	
	@NotNull(message="Price cannot be empty")
	@Min(value = 0, message = "Price cannot be negative")
	private int price;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	

}
