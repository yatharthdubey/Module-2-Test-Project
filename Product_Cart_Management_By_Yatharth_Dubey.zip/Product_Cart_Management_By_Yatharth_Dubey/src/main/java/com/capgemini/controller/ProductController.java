package com.capgemini.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.beans.Product;
import com.capgemini.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	IProductService service; //Creating reference of Service layer

	Product product;

	@RequestMapping(method = RequestMethod.POST, value = "/products")
	public Product createProduct(@Valid @RequestBody Product product) {

		return service.createProduct(product); //calling createProduct() method of service layer and returning Product object to postman
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/products")
	public Product updateProduct(@Valid @RequestBody Product product) {

		return service.updateProduct(product); //calling updateProduct() method of service layer and returning Product object to postman
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/products/{id}")
	public String deleteProduct(@PathVariable String id) {
		
		if(service.deleteProduct(id))
			return "Product Deleted Successfully";  //calling deleteProduct() method of service layer and returning String to postman
		return null;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/products/{id}")
	public Product veiwProduct(@PathVariable String id) {

		return service.viewProduct(id); //calling viewProduct() method of service layer and returning Product object to postman
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/products")
	public List<Product> veiwAllProducts() {

		return service.viewAllProducts(); //calling viewAllProduct() method of service layer and returning List of Product objects to postman
	}

}
